import React from 'react'

const Main = () => {
  return (
    <div>
      hy
    </div>
  )
}

export default Main
