
import LawyerHeader from "./LawyerHeader";
import "./LawyerHome.css";
const Lawyer_home = () => {
  return (
    <>
      <LawyerHeader />
    </>
  )
};

export default Lawyer_home;
